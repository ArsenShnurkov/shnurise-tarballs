﻿#if PORTABLE

namespace System
{
    internal interface ICloneable
    {
        object Clone();
    }
}

#endif
