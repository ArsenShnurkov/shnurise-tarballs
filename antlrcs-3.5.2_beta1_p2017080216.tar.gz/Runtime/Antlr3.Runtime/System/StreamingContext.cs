﻿#if NETSTANDARD

namespace System.Runtime.Serialization
{
    internal struct StreamingContext
    {
    }
}

#endif
