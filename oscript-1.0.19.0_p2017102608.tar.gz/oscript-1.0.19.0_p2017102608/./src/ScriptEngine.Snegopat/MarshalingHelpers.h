#pragma once

#include <comdef.h>

WCHAR* stringBuf(System::String^ str);

BSTR stringToBSTR(System::String^ str);
